//
//  Bridging-Header.h
//  discount_ascii_warehouse
//
//  Created by Vitor Oliveira on 6/11/16.
//  Copyright © 2016 Vitor Oliveira. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h
    #import "CCBottomRefreshControl/UIScrollView+BottomRefreshControl.h"
    #import <FBSDKCoreKit/FBSDKCoreKit.h>
    #import <FBSDKLoginKit/FBSDKLoginKit.h>
#endif