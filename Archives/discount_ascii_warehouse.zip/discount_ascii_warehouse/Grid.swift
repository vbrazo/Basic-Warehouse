//
//  Grid.swift
//  discount_ascii_warehouse
//
//  Created by Vitor Oliveira on 6/1/16.
//  Copyright © 2016 Vitor Oliveira. All rights reserved.
//

import UIKit

class CollectionsGrid: UICollectionViewCell {
    
    @IBOutlet weak var lblFace: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var labelOneMoreInStock: UILabel!
    @IBOutlet weak var btnBuyNow: UIButton!
    
}