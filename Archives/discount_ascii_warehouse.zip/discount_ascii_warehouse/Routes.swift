//
//  Routes.swift
//  discount_ascii_warehouse
//
//  Created by Vitor Oliveira on 6/9/16.
//  Copyright © 2016 Vitor Oliveira. All rights reserved.
//

struct ROUTES {
    
    static let base_api = "http://74.50.59.155:5000/api"
    static let search = "\(base_api)/search"
    
}