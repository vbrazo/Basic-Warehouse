//
//  Schema.swift
//  discount_ascii_warehouse
//
//  Created by Vitor Oliveira on 6/7/16.
//  Copyright © 2016 Vitor Oliveira. All rights reserved.
//

import Foundation
import CoreData

@objc(Warehouse)
public class Warehouse: NSManagedObject {
    
}