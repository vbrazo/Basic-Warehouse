//
//  Tag+CoreDataProperties.swift
//  discount_ascii_warehouse
//
//  Created by Vitor Oliveira on 6/7/16.
//  Copyright © 2016 Vitor Oliveira. All rights reserved.
//

import CoreData

public extension Tag {
    
    @NSManaged var name: String
    
}